<div class="row-fluid">
    <div class="span12">

        <div class="box ">
            <div class="title">
                <h4>
                    <span class="icon16 icomoon-icon-equalizer-2"></span>
                    <span>Registrar nuevo Articulo</span>
                </h4>
            </div>
            <?php echo validation_errors(); ?>
            <div class="content">
                <?php
                $attributes = array('id' => 'adminForm');
                echo form_open('bodegas/articulos/nuevo',$attributes)
                ?>

                <div class="span6">
                    <div class="form-field-box odd">
                        <div class="row-fluid">
                            <label class="form-label span3" for="art_descripcion">Empresa:</label>
                            <input class="span7 left validate[required]" id="emp_desc" name="emp_desc" value="<?= $empresa[0]->emp_razon_social?>" readonly type="text" />
                        </div>
                    </div>
                    <div class="form-field-box odd">
                        <div class="row-fluid">
                            <label class="form-label span3" for="art_descripcion">Descripcion:</label>
                            <input class="span7 left validate[required]" id="art_descripcion" name="art_descripcion" type="text" />
                        </div>
                    </div>
                    <div class="form-field-box odd">
                        <div class="row-fluid">
                            <label class="form-label span3" for="art_codigo_inventario">Codigo inventario:</label>
                            <input class="span3 left validate[required]" id="art_codigo_inventario" name="art_codigo_inventario" type="text" />
                        </div>
                    </div>
                </div>
                <div class="span6">

                    <div class="form-field-box odd">
                        <div class="row-fluid">
                            <label class="form-label span3" for="art_descripcion">Cuenta compra:</label>
                            <input class="span7 left validate[required,custom[integer]]" id="art_cuenta_compra" name="art_cuenta_compra" type="text" />
                        </div>
                    </div>

                    <div class="form-field-box odd">
                        <div class="row-fluid">
                            <label class="form-label span3" for="art_descripcion">Cuenta venta:</label>
                            <input class="span7 left validate[required,custom[integer]]" id="art_cuenta_venta" name="art_cuenta_venta" type="text" />
                        </div>
                    </div>

                    <div class="form-field-box odd">
                        <div class="row-fluid">
                            <label class="form-label span3" for="art_descripcion">Cuenta traslado:</label>
                            <input class="span7 left validate[required,custom[integer]]" id="art_cuenta_traslado" name="art_cuenta_traslado" type="text" />
                        </div>
                    </div>

                    <div class="form-field-box odd">
                        <div class="row-fluid">
                            <label class="form-label span3" for="art_descripcion">Grupo:</label>
                            <div class="span7 controls sel">
                                <select class="nostyle required" id="grp_parent" name="grp_parent">
                                    <option value="0">Seleccionar grupo</option>
                                    <?php
                                    if(!empty($grupos)){
                                        foreach($grupos as $row)
                                        {
                                            echo '<option value="'.$row->grp_id.'">'.$row->grp_descripcion.'</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-field-box odd">
                        <div class="row-fluid">
                            <label class="form-label span3" for="art_descripcion">Sub grupo:</label>
                            <div class="span7 controls sel" id="subgrupos_area">
                                <select class="nostyle required" id="combobox" name="grp_parent">
                                    <option value="0">Seleccionar sub grupo</option>
                                </select>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="clear"></div>

                <div class="pDiv">
                    <p>
                        <?= form_button(array('content'=>'<span class="icon16 icomoon-icon-checkmark white"></span>'.SIIE_BTN_SAVE,'class'=>'btn btn-success','type'=>'submit'))?>
                        <?= back() ?>
                    </p>

                </div>

                <input type="hidden" id="base_url" value="<?= site_url()?>">
                <?php
                echo form_hidden('emp_id',$emp_id);
                echo form_close();
                ?>

            </div>
            <!-- End .box -->

        </div>
    </div>
</div>