<div class="row-fluid">

    <div class="span12">

        <div class="box gradient">

            <div class="title">
                <h4>
                    <span>Listado articulos:</span>
                </h4>
            </div>
            <div class="content noPad clearfix">
                <table cellpadding="0" cellspacing="0" border="0" class="responsive dynamicTable display table table-bordered" id="listaBodegas" width="100%">
                    <thead>
                    <tr>
                        <th>Descripción</th>
                        <th>Codigo inventario</th>
                        <th>Cuenta compra</th>
                        <th>Cuenta venta</th>
                        <th>Cuenta traslado</th>
                        <th>Precio promedio</th>
                   
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    if(!empty($articulos))
                    {
                        foreach($articulos as $row)
                        {
                            ?>
                            <tr label="<?= $row->art_descripcion ?>" value="<?= $row->art_id?>">
                                <td><?= $row->art_descripcion?></td>
                                <td><?= $row->art_codigo_inventario?></td>
                                <td><?= $row->art_cuenta_compra ?></td>
                                <td><?= $row->art_cuenta_venta ?></td>
                                <td><?= $row->art_cuenta_traslado ?></td>
                                <td><?= $row->art_precio_promedio ?></td>
                            </tr>
                        <?php
                        }

                    }
                    ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>